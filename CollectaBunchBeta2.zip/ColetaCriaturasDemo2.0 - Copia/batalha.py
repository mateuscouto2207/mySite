import random
box = ["Geleia espinhenta","Geleia espinhenta","Geleia espinhenta","Geleia espinhenta","Geleia espinhenta"]
grupo = ["Geleia rosa","Geleia malhada","Geleia espinhenta"]
criatura = random.choice(grupo)
chance = [1,2,3,4,5,6]
mochila = ["Espeto com Xarope"]
efeitos = []
seus_efeitos = []
acoes = ["ataque","efeitos"]
escolhido = str
permanencia = 0
vida = 0
ataque = 0
suavida = 0
seuataque = 0
escolha = 0
critrange = []
your_critrange = []
critpick = int
addcrit = 0
syrup = 1
count = 1
object = str
object_chosen = str
is_syrupy = False
is_dead = False
is_opponent_dead = False
is_captured = False
pode_evoluir = bool
escolha_criatura = int
box_count = 0
box_chose = int
second_phase_octrovao = False
brawl_type = str
spend = 0
reset = 0
def initial():
    global escolha_criatura
    global suacriatura
    print("Bom dia!")
    print("Escolha sua criatura!")
    print("Geleia rosa = 1")
    print("Geleia malhada = 2")
    print("Geleia espinhenta = 3")
    escolha_criatura = int(input())
    if escolha_criatura == 1:
        suacriatura = "Geleia rosa"
    elif escolha_criatura == 2:
        suacriatura = "Geleia malhada"
    elif escolha_criatura == 3:
        suacriatura = "Geleia espinhenta"
    box.append(suacriatura)
def enciclopedia():
    global vida
    global ataque
    global efeitos
    global efeito_escolhido
    global critrange
    if criatura == "Geleia rosa":
        vida = 150
        ataque = 100
        efeitos = ["Olhos fofos","Grudento"]
        efeito_escolhido = random.choice(efeitos)
        critrange = [1,2,3,4,5,6,7]
    elif criatura == "Geleia malhada":
        vida = 50
        ataque = 200
        efeitos = ["Raiva aniquiladora","Caçador esguio"]
        efeito_escolhido = random.choice(efeitos)
        critrange = [1,2,3,4,5,6,7,8,9]
    elif criatura == "Geleia espinhenta":
        vida = 200
        ataque = 50
        efeitos = ["Carapaça robusta","Rosto rabugento"]
        efeito_escolhido = random.choice(efeitos)
        critrange = [1,2,3,4,5,6]
    elif criatura == "Octrovão":
        vida = 6500
        ataque = 500
        efeitos = ["Redemoinho tempestuoso"]
        efeito_escolhido = random.choice(efeitos)
        critrange = [1,2,3,4,5]
def not_healciclopedia():
    global vida
    global ataque
    global efeitos
    global efeito_escolhido
    global critrange
    if criatura == "Octrovão":
        ataque = 500
        efeitos = ["Redemoinho tempestuoso"]
        efeito_escolhido = random.choice(efeitos)
        critrange = [1,2,3,4,5]
def criaturitodex():
    global suavida
    global seuataque
    global seus_efeitos
    global your_critrange
    global seu_efeito_escolhido
    global pode_evoluir
    if suacriatura == "Geleia rosa":
        suavida = 150
        seuataque = 100
        seus_efeitos = ["Olhos fofos","Grudento"]
        seu_efeito_escolhido = random.choice(seus_efeitos)
        your_critrange = [1,2,3,4,5,6,7]
        pode_evoluir = True
    elif suacriatura == "Grandosado":
        suavida = 1500
        seuataque = 1000
        seus_efeitos = ["Olhos fofos","Grudento","Sono conjunto"]
        seu_efeito_escolhido = random.choice(seus_efeitos)
        your_critrange = [1,2,3,4,5]
        pode_evoluir = False
    elif suacriatura == "Geleia malhada":
        suavida = 50
        seuataque = 200
        seus_efeitos = ["Raiva aniquiladora","Caçador esguio"]
        seu_efeito_escolhido = random.choice(seus_efeitos)
        your_critrange = [1,2,3,4,5,6,7,8,9]
        pode_evoluir = True
    elif suacriatura == "Caçalhado":
        suavida = 500
        seuataque = 2000
        seus_efeitos = ["Raiva aniquiladora","Caçador esguio","Corta tensão"]
        seu_efeito_escolhido = random.choice(seus_efeitos)
        your_critrange = [1,2,3,4,5,6,7]
        pode_evoluir = False
    elif suacriatura == "Geleia espinhenta":
        suavida = 200
        seuataque = 1000
        seus_efeitos = ["Carapaça robusta","Rosto rabugento"]
        seu_efeito_escolhido = random.choice(seus_efeitos)
        your_critrange = [1,2,3,4,5,6]
        pode_evoluir = True
    elif suacriatura == "Brutonhento":
        suavida = 2000
        seuataque = 500
        seus_efeitos = ["Carapaça robusta","Rosto rabugento","Foco pesado"]
        seu_efeito_escolhido = random.choice(seus_efeitos)
        your_critrange = [1,2,3,4]
        pode_evoluir = False
    elif criatura == "Octrovão":
        suavida = 2500
        seuataque = 500
        seus_efeitos = ["Redemoinho tempestuoso"]
        seu_efeito_escolhido = random.choice(efeitos)
        your_critrange = [1,2,3,4,5]
        pode_evoluir = False
def effect_manager():
    global seuataque
    global suavida
    global vida
    global ataque
    global critrange
    global your_critrange
    global is_dead
    print(criatura,"utiliza",efeito_escolhido,"!")
    if efeito_escolhido == "Olhos fofos":
        print(suacriatura,"acha fofo!")
        if pode_evoluir == True:
            print("O ataque de",suacriatura,"caiu levemente!")
            seuataque -= 25
        else:
            print("O ataque de",suacriatura,"caiu drasticamente!")
            seuataque -= 250
    elif efeito_escolhido == "Grudento":
        print(criatura,"tem um líquido espesso espelido!")
        if pode_evoluir == True:
            print("O ataque de",suacriatura,"caiu levemente!")
            print("A capacidade de fazer críticos de",suacriatura,"caiu levemente!")
            seuataque -= 12
            your_critrange.append(11)
        else:
            print("O ataque de",suacriatura,"caiu drasticamente!")
            print("A capacidade de fazer críticos de",suacriatura,"caiu drasticamente!")
            seuataque -= 125
            your_critrange.append(11)
            your_critrange.append(12)
    elif efeito_escolhido == "Sono conjunto":
        print(suacriatura,"está bocejando")
        if pode_evoluir == True:
            print("O ataque de",suacriatura,"caiu levemente!")
            print("A capacidade de fazer críticos de",criatura,"aumentou levemente!")
            seuataque -= 50
            critrange.pop()
        else:
            print("O ataque de",suacriatura,"caiu drasticamente!")
            print("A capacidade de fazer críticos de",criatura,"aumentou drasticamente!")
            seuataque -= 500
            critrange.pop()
            critrange.pop()
    elif efeito_escolhido == "Raiva aniquiladora":
        print(suacriatura,"está muito brava!")
        if pode_evoluir == True:
            print("O ataque de",suacriatura,"aumentou levemente!")
            print("A vida de",suacriatura,"caiu levemente!")
            seuataque += 25
            suavida -= 50
        else:
            print("O ataque de",suacriatura,"aumentou levemente!")
            print("A vida de",suacriatura,"caiu drasticamente!")
            seuataque += 250
            suavida -= 500
    elif efeito_escolhido == "Caçador esguio":
        print(criatura,"perde o oponente de vista!")
        if pode_evoluir == True:
            print("A capacidade de fazer críticos de",criatura,"aumentou levemente!")
            critrange.pop()
        else:
            print("A capacidade de fazer críticos de",criatura,"aumentou drasticamente!")
            critrange.pop()
            critrange.pop()
    elif efeito_escolhido == "Corta tensão":
        print(criatura,"não se importa com a fúria do oponente!")
        if pode_evoluir == True:
            print("O ataque de",criatura,"aumentou levemente!")
            print("A capacidade de fazer críticos de",suacriatura,"aumentou levemente!")
            your_critrange.pop()
            ataque += 50
        else:
            print("O ataque de",criatura,"aumentou drasticamente!")
            print("A capacidade de fazer críticos de",suacriatura,"caiu levemente!")
            your_critrange.append(11)
            ataque += 500
    elif efeito_escolhido == "Carapaça robusta":
        print(criatura,"se protege!")
        if pode_evoluir == True:
            print("A vida de",criatura,"aumentou levemente!")
            vida += 50
        else:
            print("A vida de",criatura,"aumentou drasticamente!")
            vida += 500
    elif efeito_escolhido == "Rosto rabugento":
        print(suacriatura,"está pensando sobre o que fazer na situação!")
        if pode_evoluir == True:
            print("O ataque de",criatura,"aumentou levemente!")
            ataque += 25
        else:
            print("O ataque de",criatura,"aumentou drasticamente!")
            ataque += 250
def your_effect_manager():
    global seuataque
    global suavida
    global vida
    global ataque
    global critrange
    global your_critrange
    global is_dead
    print(suacriatura,"utiliza",seu_efeito_escolhido,"!")
    if seu_efeito_escolhido == "Olhos fofos":
        print(criatura,"acha fofo!")
        if pode_evoluir == True:
            print("O ataque de",criatura,"caiu levemente!")
            ataque -= 25
        else:
            print("O ataque de",criatura,"caiu drasticamente!")
            ataque -= 250
    elif seu_efeito_escolhido == "Grudento":
        print(suacriatura,"tem um líquido espesso espelido!")
        if pode_evoluir == True:
            print("O ataque de",criatura,"caiu levemente!")
            print("A capacidade de fazer críticos de",suacriatura,"caiu levemente!")
            ataque -= 12
            critrange.append(11)
        else:
            print("O ataque de",criatura,"caiu drasticamente!")
            print("A capacidade de fazer críticos de",suacriatura,"caiu drasticamente!")
            ataque -= 125
            critrange.append(11)
            critrange.append(12)
    elif seu_efeito_escolhido == "Sono conjunto":
        print(criatura,"está bocejando")
        if pode_evoluir == True:
            print("O ataque de",criatura,"caiu levemente!")
            print("A capacidade de fazer críticos de",suacriatura,"aumentou levemente!")
            ataque -= 50
            your_critrange.pop()
        else:
            print("O ataque de",criatura,"caiu drasticamente!")
            print("A capacidade de fazer críticos de",suacriatura,"aumentou drasticamente!")
            ataque -= 500
            your_critrange.pop()
            your_critrange.pop()
    elif seu_efeito_escolhido == "Raiva aniquiladora":
        print(criatura,"está muito brava!")
        if pode_evoluir == True:
            print("O ataque de",criatura,"aumentou levemente!")
            print("A vida de",criatura,"caiu levemente!")
            ataque += 25
            vida -= 50
        else:
            print("O ataque de",criatura,"aumentou levemente!")
            print("A vida de",criatura,"caiu drasticamente!")
            ataque += 250
            vida -= 500
    elif seu_efeito_escolhido == "Caçador esguio":
        print(criatura,"perde o oponente de vista!")
        if pode_evoluir == True:
            print("A capacidade de fazer críticos de",suacriatura,"aumentou levemente!")
            your_critrange.pop()
        else:
            print("A capacidade de fazer críticos de",suacriatura,"aumentou drasticamente!")
            your_critrange.pop()
            your_critrange.pop()
    elif seu_efeito_escolhido == "Corta tensão":
        print(suacriatura,"não se importa com a fúria do oponente!")
        if pode_evoluir == True:
            print("O ataque de",suacriatura,"aumentou levemente!")
            print("A capacidade de fazer críticos de",criatura,"aumentou levemente!")
            critrange.pop()
            seuataque += 50
        else:
            print("O ataque de",suacriatura,"aumentou drasticamente!")
            print("A capacidade de fazer críticos de",criatura,"caiu levemente!")
            critrange.append(11)
            seuataque += 500
    elif seu_efeito_escolhido == "Carapaça robusta":
        print(suacriatura,"se protege!")
        if pode_evoluir == True:
            print("A vida de",suacriatura,"aumentou levemente!")
            suavida += 50
        else:
            print("A vida de",suacriatura,"aumentou drasticamente!")
            suavida += 500
    elif seu_efeito_escolhido == "Rosto rabugento":
        print(criatura,"está pensando sobre o que fazer na situação!")
        if pode_evoluir == True:
            print("O ataque de",suacriatura,"aumentou levemente!")
            seuataque += 25
        else:
            print("O ataque de",suacriatura,"aumentou drasticamente!")
            seuataque += 250
def item_use():
    if object_chosen == "Espeto com Xarope":
        global is_syrupy
        print(suacriatura,"está coberta por xarope!")
        is_syrupy = True
def crit_manager():
    global critrange
    global critpick
    global addcrit
    global ataque
    critpick = random.choice(critrange)
    if critpick == 1:
        addcrit = ataque/4
def evolution_manager():
    global suacriatura
    if suacriatura == "Geleia rosa":
        print(suacriatura,"evoluiu para Grandosado!")
        suacriatura = "Grandosado"
    elif suacriatura == "Geleia malhada":
        print(suacriatura,"evoluiu para Caçalhado!")
        suacriatura = "Caçalhado"
    elif suacriatura == "Geleia espinhenta":
        print(suacriatura,"evoluiu para Brutonhento!")
        suacriatura = "Brutonhento"
def evolution_action_manager():
    global escolha
    if pode_evoluir == True:
        evolution_manager()
    else:
        print(suacriatura,"não pode evoluir, escolha outro movimento")
        escolha = int(input())
def box_access():
    global box_count
    global box_chose
    global suacriatura
    print("Até mais",suacriatura,"!")
    box.pop()
    box.append(suacriatura)
    print("Escolha uma criatura para trocar!")
    while box_count + 1 < len(box):
        box_count = box_count + 1
        print(box_count,")",box[box_count])
    box_count = 0
    box_chose = int(input())
    suacriatura = box[box_chose]
initial()
def brawl():
    global brawl_type
    global criatura
    global suacriatura
    global escolha_criatura
    global vida
    global suavida
    global ataque
    global seuataque
    global is_dead
    global is_opponent_dead
    global is_captured
    global is_syrupy
    global escolha
    global escolhido
    global efeitos
    global efeito_escolhido
    global seus_efeitos
    global seu_efeito_escolhido
    global critrange
    global your_critrange
    global critpick
    global chance
    global permanencia
    global syrup
    global mochila
    global box
    global box_chose
    global box_count
    global count
    global acoes
    global addcrit
    global pode_evoluir
    global object
    global object_chosen
    enciclopedia()
    criaturitodex()
    suacriatura = box[0]
    brawl_type = "Bush"
    if vida > 0:
        is_dead = False
    print("Uma", criatura,"apareceu!")
    print("Vai", suacriatura,"!")
    while is_dead == False and is_opponent_dead == False and is_captured == False:
        print("Vida de", criatura,":",vida)
        print("Vida de sua criatura:",suavida)
        print("Atacar = 1")
        print("Efeitos ->",seu_efeito_escolhido,"= 2")
        print("Capturar = 3")
        print("Itens = 4")
        print("Trocar = 5")
        print("Evoluir? = 6")
        escolha = int(input())
        if escolha == 1:
            print(suacriatura,"ataca!")
            vida = vida - seuataque
        elif escolha == 2:
            your_effect_manager()
        elif escolha == 3:
            if vida <= 500:
                chance.remove(3)
                chance.remove(4)
                chance.remove(5)
                chance.remove(6)
                print("Você acerta!")
                permanencia = random.choice(chance)
                if permanencia == 1:
                    vida = 0
                    is_captured = True
                else:
                    print("Tão perto!", criatura,"fugiu!")
                    chance.append(3)
                    chance.append(4)
                    chance.append(5)
                    chance.append(6)
            elif vida <= 1000:
                chance.remove(5)
                chance.remove(6)
                print("Você acerta!")
                permanencia = random.choice(chance)
                if permanencia == 1:
                    vida = 0
                    ataque = 0
                    is_captured = True
                else:
                    print("Que pena,", criatura,"fugiu!")
                    chance.append(5)
                    chance.append(6)
            else:
                print("Você acerta!")
                permanencia = random.choice(chance)
                if permanencia == 1:
                    vida = 0
                    is_captured = True
                else:
                    print(criatura,"fugiu!")
        elif escolha == 4:
            if mochila == []:
                print("Sua mochila está vazia")
                escolha = int(input())
                print("Atacar = 1")
                print("Efeitos ->",seu_efeito_escolhido,"= 2")
                print("Capturar = 3")
                print("Itens = 4")
                print("Trocar = 5")
                print("Evoluir? = 6")
            else:
                while count <= len(mochila):
                    count = count - 1
                    object = mochila[count]
                    print(object)
                    count = count + 2
                object_chosen = input()
                count = 1
                while count <= len(mochila):
                    count = count - 1
                    object = mochila[count]
                    count = count + 2
                    if object == object_chosen:
                        print(object_chosen,"foi utilizado!")
                        item_use()
                        mochila.remove(object_chosen)
        elif escolha == 5:
            box_access()
            criaturitodex()
        elif escolha == 6:
            evolution_action_manager()
            criaturitodex()
        if vida <= 0 and is_captured == False:
            is_opponent_dead = True
        if is_opponent_dead == False and is_captured == False and syrup != 2:#ataque ou efeito para o oponente
            escolhido = random.choice(acoes)
            if escolhido == "ataque":
                print(criatura,"ataca")
                crit_manager()
                suavida = suavida - (ataque + addcrit)
                if suavida <= 0:
                    is_dead = True
                if addcrit != 0:
                    print("Foi um ataque crítico!")
                if is_syrupy == True:
                    syrup = syrup + 1
            else:
                effect_manager()
        elif is_opponent_dead == False and syrup == 2:#checa se esta com espeto com xarope
            print(criatura,"está presa no xarope!")
            syrup = 0
            is_syrupy = False
        elif is_opponent_dead == False and is_captured == True:
            print("Você captura")
    check_life()
def check_life():
    global escolha
    global reset
    if is_dead == True:#morte sua criatura
        print("Sua criatura está incapacitada!")
        print("Quer trocar de criatura?")
        print("Sim = 1")
        escolha = int(input())
        if escolha == 1:
            box_access()
            if brawl_type == "Bush":
                brawl()
                criaturitodex()
                reset = 1
            elif brawl_type == "Octobrawl":
                criaturitodex()
                octrovao_brawl(reset = 1)
    if vida <= 0 and is_captured == True:#criatura capturada
        if len(box) <= 6:
            print(criatura, "foi movida para o seu armazenamento!")
            box.append(criatura)
        else:
            print("Seu armazenamento já está cheio!")
            print("Você soltou a criatura!")
    elif vida <= 0 and is_captured == False:#criatura morte
        print(criatura, "foi derrotada")
def octrovao_brawl(reset):
    global brawl_type
    global criatura
    global suacriatura
    global escolha_criatura
    global vida
    global suavida
    global ataque
    global seuataque
    global is_dead
    global is_opponent_dead
    global is_captured
    global is_syrupy
    global escolha
    global escolhido
    global efeitos
    global efeito_escolhido
    global seus_efeitos
    global seu_efeito_escolhido
    global critrange
    global your_critrange
    global critpick
    global chance
    global permanencia
    global syrup
    global mochila
    global box
    global box_chose
    global box_count
    global count
    global acoes
    global addcrit
    global pode_evoluir
    global object
    global object_chosen
    global second_phase_octrovao
    global spend
    brawl_type = "Octobrawl"
    criatura = "Octrovão"
    suacriatura = box[0]
    if reset != 1:
        enciclopedia()
        print("Um", criatura,"gigante apareceu!")
    else:
        not_healciclopedia()
    criaturitodex()
    print("Vai", suacriatura,"!")
    if vida > 0:
        is_dead = False
    while is_dead == False and is_opponent_dead == False and is_captured == False:
        print("Vida de", criatura,":",vida)
        print("Vida de sua criatura:",suavida)
        print("Atacar = 1")
        print("Efeitos ->",seu_efeito_escolhido,"= 2")
        print("Itens = 3")
        print("Trocar = 4")
        print("Evoluir? = 5")
        escolha = int(input())
        if escolha == 1:
            print(suacriatura,"ataca!")
            vida = vida - seuataque
        elif escolha == 2:
            your_effect_manager()
        elif escolha == 3:
            if mochila == []:
                print("Sua mochila está vazia")
                escolha = int(input())
                print("Atacar = 1")
                print("Efeitos ->",seu_efeito_escolhido,"= 2")
                print("Capturar = 3")
                print("Itens = 4")
                print("Trocar = 5")
                print("Evoluir? = 6")
            else:
                while count <= len(mochila):
                    count = count - 1
                    object = mochila[count]
                    print(object)
                    count = count + 2
                object_chosen = input()
                count = 1
                while count <= len(mochila):
                    count = count - 1
                    object = mochila[count]
                    count = count + 2
                    if object == object_chosen:
                        print(object_chosen,"foi utilizado!")
                        item_use()
                        mochila.remove(object_chosen)
        elif escolha == 4:
            box_access()
            criaturitodex()
        elif escolha == 5:
            evolution_action_manager()
            criaturitodex()
        if vida <= 0:
            is_opponent_dead = True
        if is_opponent_dead == False and syrup != 2:#ataque ou efeito para o oponente
            if second_phase_octrovao == True:
                effect_manager()
                spend = 1
                second_phase_octrovao = False
            else:
                print(criatura,"ataca")
                crit_manager()
                suavida = suavida - (ataque + addcrit)
                if suavida <= 0:
                    is_dead = True
                if addcrit != 0:
                    print("Foi um ataque crítico!")
                if is_syrupy == True:
                    syrup = syrup + 1
        elif is_opponent_dead == False and syrup == 2:#checa se esta com espeto com xarope
            print(criatura,"está presa no xarope!")
            syrup = 0
            is_syrupy = False
        if vida <= 3000 and spend == 0:
            print(criatura,"está furiosa e parece estar carrengando seu poder!")
            second_phase_octrovao = True
    check_life()
    if vida == 0:
        print(criatura,"está incapacitada!")
        print("É sua chance de capturar",criatura,"!")
        print("Você quer capturar",criatura,"?")
        print("Sim = 1")
        print("Não = 2")
        escolha = int(input())
        if escolha == 1:
            print("Você capturou",criatura)
            print(criatura,"foi movida para o seu armazenamento!")
            box.append(criatura)
octrovao_brawl(reset = 0)